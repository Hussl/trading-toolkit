
import argparse, pandas as pd

def filter_signals(df):
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    # Base filters
    f = df[
        (df["confidence"] >= 0.65) &
        (df["rsi"].between(40, 60)) &
        (df["atr_volatility"] >= 0.2)
    ].copy()
    # Keep top 3 by day
    f["day"] = f["timestamp"].dt.date
    f = f.sort_values(["day", "confidence"], ascending=[True, False])
    out = f.groupby("day").head(3).drop(columns=["day"])
    return out

def main(inp, outp):
    df = pd.read_csv(inp)
    out = filter_signals(df)
    out.to_csv(outp, index=False)
    print(f"Saved {len(out)} signals to {outp}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="signals.csv")
    ap.add_argument("--output", default="filtered.csv")
    args = ap.parse_args()
    main(args.input, args.output)
