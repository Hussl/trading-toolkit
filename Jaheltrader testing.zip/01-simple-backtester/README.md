# Simple Backtester (SMA Crossover)

A minimal backtesting script for a **moving average crossover** strategy using `pandas` and `yfinance`.
- Instruments: any Yahoo Finance ticker (e.g., BTC-USD, AAPL)
- Strategy: Buy when SMA(short) crosses above SMA(long); sell when it crosses below.
- Risk: fixed percent per trade; equity curve and basic metrics printed.

## How to run
```bash
pip install -r requirements.txt
python backtest.py --ticker BTC-USD --start 2022-01-01 --end 2025-08-01 --fast 20 --slow 50 --risk 0.01
```
Outputs:
- Console summary with CAGR, win rate, max drawdown (simple approximations)
- `trades.csv` with entries/exits
- `equity_curve.csv` with daily equity

## Files
- `backtest.py` – main script
- `requirements.txt` – dependencies
