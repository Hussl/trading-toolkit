
import argparse, pandas as pd, numpy as np, yfinance as yf

def metrics(equity):
    ret = equity.pct_change().fillna(0.0)
    ann = 252
    cagr = (equity.iloc[-1] / equity.iloc[0]) ** (ann / len(equity)) - 1 if len(equity) > 1 else 0
    vol = ret.std() * (ann ** 0.5)
    sharpe = (ret.mean() * ann) / vol if vol != 0 else 0
    # Max drawdown
    roll_max = equity.cummax()
    dd = equity / roll_max - 1.0
    mdd = dd.min()
    return {"CAGR": cagr, "Sharpe": sharpe, "MaxDD": mdd}

def backtest(ticker, start, end, fast, slow, risk):
    data = yf.download(ticker, start=start, end=end, auto_adjust=True, progress=False)
    if data.empty:
        raise SystemExit("No data returned. Check ticker or internet connection.")
    data["SMA_fast"] = data["Close"].rolling(fast).mean()
    data["SMA_slow"] = data["Close"].rolling(slow).mean()
    data["signal"] = 0
    data.loc[data["SMA_fast"] > data["SMA_slow"], "signal"] = 1
    data.loc[data["SMA_fast"] < data["SMA_slow"], "signal"] = -1
    data["position"] = data["signal"].diff().fillna(0)

    cash, shares = 10000.0, 0.0
    equity_curve = []
    trades = []

    for dt, row in data.iterrows():
        price = row["Close"]
        # generate trade on cross
        if row["position"] == 1:  # buy
            if shares == 0:
                risk_amount = cash * risk
                # use risk as fraction of cash; buy as many shares as risk_amount / price
                qty = max(int(risk_amount / price), 1)
                cost = qty * price
                if cost <= cash:
                    cash -= cost
                    shares += qty
                    trades.append({"date": dt, "side": "BUY", "price": price, "qty": qty})
        elif row["position"] == -1:  # sell
            if shares > 0:
                cash += shares * price
                trades.append({"date": dt, "side": "SELL", "price": price, "qty": shares})
                shares = 0

        equity = cash + shares * price
        equity_curve.append({"date": dt, "equity": equity})

    # close any open
    if shares > 0:
        price = data["Close"].iloc[-1]
        cash += shares * price
        trades.append({"date": data.index[-1], "side": "SELL", "price": price, "qty": shares})
        shares = 0
        equity_curve[-1]["equity"] = cash

    ec = pd.DataFrame(equity_curve).set_index("date")["equity"]
    m = metrics(ec)
    # Win rate approximation
    wins, losses = 0, 0
    for i in range(1, len(trades), 2):
        buy = trades[i-1]["price"]
        sell = trades[i]["price"]
        if sell > buy:
            wins += 1
        else:
            losses += 1
    winrate = wins / (wins + losses) if (wins + losses) > 0 else 0

    pd.DataFrame(trades).to_csv("trades.csv", index=False)
    ec.to_frame().to_csv("equity_curve.csv")

    print(f"Trades: {len(trades)//2} | WinRate: {winrate:.2%}")
    print(f"CAGR: {m['CAGR']:.2%} | Sharpe: {m['Sharpe']:.2f} | MaxDD: {m['MaxDD']:.2%}")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", default="BTC-USD")
    ap.add_argument("--start", default="2022-01-01")
    ap.add_argument("--end", default=None)
    ap.add_argument("--fast", type=int, default=20)
    ap.add_argument("--slow", type=int, default=50)
    ap.add_argument("--risk", type=float, default=0.01)
    args = ap.parse_args()
    backtest(args.ticker, args.start, args.end, args.fast, args.slow, args.risk)
